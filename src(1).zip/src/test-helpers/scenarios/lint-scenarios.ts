import type { LintScenario } from "./types"

// NOTE: Structural lint now computes outlinks from the `related:` frontmatter
// array, not from body [[wikilinks]]. Scenarios must set `related: [slug]` in
// frontmatter to define outlinks.

function pageWithRelated(title: string, related: string[], body: string): string {
  return `---
title: ${title}
related: [${related.join(", ")}]
---

# ${title}

${body}
`
}

export const lintScenarios: LintScenario[] = [
  // 1. clean-wiki — fully interlinked, no findings
  {
    name: "structural/clean-wiki",
    description:
      "Two content pages cross-link each other via related. No orphans, no broken " +
      "links, no no-outlinks. Structural lint returns an empty result.",
    initialWiki: {
      "wiki/index.md": "# Index\n\n| 页面标题 | 路径 |\n|---|---|\n| attention | wiki/concepts/attention.md |\n| transformer | wiki/concepts/transformer.md |\n",
      "wiki/attention.md": pageWithRelated("Attention", ["transformer"], "See the transformer architecture."),
      "wiki/transformer.md": pageWithRelated("Transformer", ["attention"], "Built on the attention mechanism."),
    },
    expected: {
      structural: [],
    },
  },

  // 2. orphan-page — no inbound related references
  {
    name: "structural/orphan-page",
    description:
      "orphan.md references attention.md in its related but no page references " +
      "orphan.md. Structural lint should flag it as orphan, nothing else.",
    initialWiki: {
      "wiki/index.md": "# Index\n\n| 页面标题 | 路径 |\n|---|---|\n| attention | wiki/concepts/attention.md |\n| transformer | wiki/concepts/transformer.md |\n",
      "wiki/attention.md": pageWithRelated("Attention", ["transformer"], "Related to transformer."),
      "wiki/transformer.md": pageWithRelated("Transformer", ["attention"], "Built on attention."),
      "wiki/orphan.md": pageWithRelated("Orphan", ["attention"], "References attention but nobody references back."),
    },
    expected: {
      structural: [{ type: "orphan", page: "orphan.md" }],
    },
  },

  // 3. broken-link — related reference to a page that doesn't exist
  {
    name: "structural/broken-link",
    description:
      "attention.md has a related reference to nonexistent-page which has " +
      "no corresponding file. Structural lint must flag the broken reference " +
      "and name it in the detail.",
    initialWiki: {
      "wiki/index.md": "# Index\n\n| 页面标题 | 路径 |\n|---|---|\n| attention | wiki/concepts/attention.md |\n| transformer | wiki/concepts/transformer.md |\n",
      "wiki/attention.md": pageWithRelated("Attention", ["transformer", "nonexistent-page"], "Related to transformer and a missing page."),
      "wiki/transformer.md": pageWithRelated("Transformer", ["attention"], "Built on attention."),
    },
    expected: {
      structural: [
        {
          type: "broken-link",
          page: "attention.md",
          linkName: "nonexistent-page",
        },
      ],
    },
  },

  // 4. no-outlinks — a page has no related references
  {
    name: "structural/no-outlinks",
    description:
      "leaf.md is referenced-by transformer.md but has no related entries " +
      "of its own. Lint should flag 'no-outlinks' on leaf.md.",
    initialWiki: {
      "wiki/index.md": "# Index\n\n| 页面标题 | 路径 |\n|---|---|\n| attention | wiki/concepts/attention.md |\n| transformer | wiki/concepts/transformer.md |\n| leaf | wiki/concepts/leaf.md |\n",
      "wiki/attention.md": pageWithRelated("Attention", ["transformer"], "Related to transformer."),
      "wiki/transformer.md": pageWithRelated("Transformer", ["attention", "leaf"], "Uses attention and references leaf."),
      "wiki/leaf.md": pageWithRelated("Leaf", [], "A leaf concept with no outgoing references."),
    },
    expected: {
      structural: [{ type: "no-outlinks", page: "leaf.md" }],
    },
  },

  // 5. semantic-contradiction (LLM-backed)
  {
    name: "semantic/contradiction-found",
    description:
      "Two cross-linked pages make conflicting claims. Structural lint " +
      "sees no issues, but the mocked semantic LLM response emits a LINT " +
      "block that the parser extracts into a contradiction finding.",
    initialWiki: {
      "wiki/index.md": "# Index\n\n| 页面标题 | 路径 |\n|---|---|\n| attention | wiki/concepts/attention.md |\n| transformer | wiki/concepts/transformer.md |\n",
      "wiki/attention.md": pageWithRelated("Attention", ["transformer"], "Attention ALWAYS uses the softmax function."),
      "wiki/transformer.md": pageWithRelated("Transformer", ["attention"], "The transformer's attention layer uses a linear kernel, not softmax."),
    },
    llmResponse: [
      "Reviewing the pages I found one contradiction:",
      "",
      "---LINT: contradiction | warning | Attention function differs between pages---",
      "attention.md claims softmax is always used, but transformer.md describes a",
      "linear attention kernel. One page needs correction.",
      "PAGES: attention.md, transformer.md",
      "---END LINT---",
    ].join("\n"),
    expected: {
      structural: [],
      semantic: [
        {
          type: "semantic",
          severity: "warning",
          titleContains: "Attention function differs",
        },
      ],
    },
  },
]
