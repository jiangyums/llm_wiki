import yaml from "js-yaml"

/**
 * Clean up an LLM-generated wiki page body before it hits disk.
 *
 * Audit of one real corpus (67 entity pages from `/Test321/wiki/entities`)
 * showed 30/67 pages had frontmatter that couldn't be parsed strictly.
 * Three recurring shapes the model emits:
 *
 *   1. The whole page wrapped in a `\`\`\`yaml … \`\`\`` (or `\`\`\`md`,
 *      `\`\`\`markdown`) code fence, e.g.
 *
 *          ```yaml
 *          ---
 *          type: entity
 *          ---
 *          # Body
 *          ```
 *
 *      — looks fine in the generation context but has no place in a
 *      real .md file.
 *
 *   2. A leading `frontmatter:` key that turns the document into a
 *      malformed nested-yaml shape, e.g.
 *
 *          frontmatter:
 *          ---
 *          type: entity
 *          ---
 *
 *   3. Inline bracket-wrapped lists without the outer brackets, e.g.
 *
 *          related: [[a]], [[b]], [[c]]
 *
 *      — semantically what the model wanted (a list of related slugs),
 *      but not valid YAML flow syntax.
 *
 *   4. A frontmatter payload whose opening `---` is missing but whose
 *      closing `---` is present, e.g.
 *
 *          type: entity
 *          title: Foo
 *          ---
 *
 *   5. Unclosed double-quoted scalar values, e.g.
 *
 *          venue: "《诡秘之主》第一部·小丑
 *
 *      — the model opened a quote but forgot to close it before the
 *      newline. We append the missing `"` and re-validate.
 *
 * This sanitizer rewrites these shapes into the standard
 * `---\n…\n---\n` frontmatter form before write. It's deliberately
 * conservative: each pattern is anchored at the very start of the
 * document (or at top-level frontmatter scope), so a legitimate
 * fenced code block deep in the body or a `frontmatter:` mention
 * inside prose is left alone.
 *
 * The read-time parser still retains its fallback paths so old,
 * already-written corrupt files render correctly. Sanitizing on
 * write means newly-generated files never need that fallback,
 * which means re-ingesting an old file once cleans it up
 * permanently.
 */
export function sanitizeIngestedFileContent(content: string): string {
  let cleaned = content

  // (1) Strip an outer code fence wrapping the whole document.
  // We only act when the FIRST non-empty line is an opening fence
  // (`\`\`\`yaml`, `\`\`\`md`, `\`\`\`markdown`, or just `\`\`\``)
  // AND the LAST non-empty line is a matching closing fence. This
  // avoids touching pages that legitimately end with an unclosed
  // fence (we don't try to "fix" mid-stream truncation here).
  cleaned = stripOuterCodeFence(cleaned)

  // (2) Strip a stray `frontmatter:` line that prefixes the real
  // `---` block. Some prompts seem to make the model interpret
  // the request as "produce a YAML document with a `frontmatter`
  // key" rather than "produce a markdown document with a
  // frontmatter block".
  cleaned = stripFrontmatterKeyPrefix(cleaned)

  // (2.5) Repair a missing opening frontmatter fence when the model
  // clearly emitted frontmatter lines followed by a closing fence.
  cleaned = addMissingOpeningFrontmatterFence(cleaned)

  // (3) Repair `key: [[a]], [[b]], [[c]]` lines inside the
  // frontmatter block so they're valid YAML.
  cleaned = repairWikilinkListsInFrontmatter(cleaned)

  // (4) Repair unclosed double-quoted scalar values in frontmatter,
  // e.g. `venue: "《诡秘之主》第一部·小丑` → `venue: "《诡秘之主》第一部·小丑"`.
  cleaned = repairUnclosedQuotesInFrontmatter(cleaned)

  return cleaned
}

/** Top-level fence wrapper. Removes the open + close fence lines. */
function stripOuterCodeFence(content: string): string {
  const open = content.match(/^[ \t]*```(?:yaml|md|markdown)?[ \t]*\r?\n/)
  if (!open) return content
  const afterOpen = content.slice(open[0].length)

  // Closing fence: a final ``` on its own line, ignoring trailing
  // whitespace/newlines after it.
  const close = afterOpen.match(/\r?\n[ \t]*```[ \t]*\r?\n?\s*$/)
  if (!close) return content
  return afterOpen.slice(0, close.index)
}

/**
 * Strip a leading `frontmatter:` line followed by the real
 * frontmatter block. Only acts when the next non-empty line is
 * `---`, so a body that legitimately mentions the word
 * "frontmatter:" in prose is unaffected.
 */
function stripFrontmatterKeyPrefix(content: string): string {
  const m = content.match(/^[ \t]*frontmatter\s*:\s*\r?\n(?=[ \t]*---\s*\r?\n)/)
  if (!m) return content
  return content.slice(m[0].length)
}

function addMissingOpeningFrontmatterFence(content: string): string {
  if (/^[ \t]*---\s*(\r?\n|$)/.test(content)) return content

  const lines = content.split(/\r?\n/)
  const firstContentIdx = lines.findIndex((line) => line.trim().length > 0)
  if (firstContentIdx < 0) return content

  const first = lines[firstContentIdx].trim()
  if (!/^(type|title|created|updated|tags|related|sources)\s*:/i.test(first)) {
    return content
  }

  const searchEnd = Math.min(lines.length, firstContentIdx + 30)
  for (let i = firstContentIdx + 1; i < searchEnd; i += 1) {
    const trimmed = lines[i].trim()
    if (trimmed === "---") {
      return `---\n${lines.slice(firstContentIdx).join("\n")}`
    }
    if (/^#{1,6}\s+/.test(trimmed)) break
  }

  return content
}

/**
 * Inside the frontmatter block (between the opening `---` and the
 * closing `---`), rewrite invalid wikilink-list lines. Lines
 * outside the frontmatter block are left untouched.
 */
function repairWikilinkListsInFrontmatter(content: string): string {
  const fmRe = /^\s*---\s*\r?\n([\s\S]*?)\r?\n---\s*(\r?\n|$)/
  const m = content.match(fmRe)
  if (!m) return content

  const repairedPayload = m[1]
    .split("\n")
    .map((line) => {
      const lm = line.match(
        /^(\s*[A-Za-z_][\w-]*\s*:\s*)(\[\[[^\]]+\]\](?:\s*,\s*\[\[[^\]]+\]\])+)\s*$/,
      )
      if (!lm) return line
      const items = lm[2]
        .split(",")
        .map((s) => s.trim())
        .filter(Boolean)
        .map((s) => `"${s}"`)
        .join(", ")
      return `${lm[1]}[${items}]`
    })
    .join("\n")

  // Replace ONLY the payload between fences; preserve the original
  // fence lines and trailing newline shape.
  const prefixLen = m[0].indexOf("---") // find where `---` starts after leading whitespace
  const fmOpenLen = prefixLen + 4 // up to and including "---\n"
  return (
    content.slice(0, m.index! + fmOpenLen) + // up to and including "---\n"
    repairedPayload +
    content.slice(m.index! + fmOpenLen + m[1].length)
  )
}

/**
 * Repair unclosed double-quoted scalar values inside the frontmatter
 * block. Fixes the recurring pattern where the LLM emits:
 *
 *     venue: "《诡秘之主》第一部·小丑
 *
 * (opened a quote but forgot the closing `"`). Appends the missing
 * `"` to those lines and re-validates with js-yaml. If the repair
 * doesn't produce valid YAML, the content is returned unchanged.
 */
function repairUnclosedQuotesInFrontmatter(content: string): string {
  const fmRe = /^\s*---\s*\r?\n([\s\S]*?)\r?\n---\s*(\r?\n|$)/
  const m = content.match(fmRe)
  if (!m) return content

  const yamlPayload = m[1]

  // Fast path: valid YAML already — nothing to repair.
  try {
    yaml.load(yamlPayload, { schema: yaml.JSON_SCHEMA })
    return content
  } catch {
    // Continue to attempt repair.
  }

  // Only match scalar lines where the value starts with `"` but does
  // NOT end with `"` — the model opened a quote but forgot to close it.
  // Array lines (containing `[`) are left alone.
  const repairedPayload = yamlPayload
    .split("\n")
    .map((line) => {
      if (/^[A-Za-z_][\w-]*\s*:\s*"[^"]*$/.test(line.trim())) {
        return line + '"'
      }
      return line
    })
    .join("\n")

  // Validate that the repair fixed the YAML.
  try {
    yaml.load(repairedPayload, { schema: yaml.JSON_SCHEMA })
  } catch {
    return content
  }

  return (
    content.slice(0, m.index! + 4) +
    repairedPayload +
    content.slice(m.index! + 4 + m[1].length)
  )
}
