/**
 * Convert Obsidian-style image/file embeds `![[target]]` (and
 * `![[target|alias]]`) into standard CommonMark image syntax
 * `![alt](target)` so a commonmark renderer actually displays them.
 */
export function transformImageEmbeds(body: string): string {
  if (!body.includes("![[")) return body

  const parts = body.split(/(```[\s\S]*?```)/g)
  return parts
    .map((part, idx) =>
      idx % 2 === 1 ? part : transformImageEmbedsOutsideCode(part),
    )
    .join("")
}

const IMAGE_EMBED_RE = /!\[\[([^\]|\n]+)(?:\|([^\]\n]*))?\]\]/g

function transformImageEmbedsOutsideCode(text: string): string {
  if (!text.includes("![[")) return text
  const parts = text.split(/(`[^`\n]+`)/g)
  return parts
    .map((part, idx) => (idx % 2 === 1 ? part : replaceImageEmbeds(part)))
    .join("")
}

function replaceImageEmbeds(text: string): string {
  return text.replace(
    IMAGE_EMBED_RE,
    (_match, rawTarget: string, rawAlias?: string) => {
      const target = rawTarget.trim()
      const alias = rawAlias?.trim() ?? ""
      const alt = alias.replace(/]/g, ")")
      return `![${alt}](<${target}>)`
    },
  )
}
