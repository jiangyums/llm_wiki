/**
 * RAG-style search for ingest: instead of dumping the full index.md into the
 * LLM prompt, retrieve only the most relevant wiki pages via search.
 */
import { searchWiki } from "@/lib/search"
import { readFile, writeFile } from "@/commands/fs"

const RELATED_PAGE_MAX = 20

const CATEGORY_RANK: Record<string, number> = {
  Entities: 1,
  Concepts: 2,
}

const PATH_PREFIX_TO_CAT: [string, string][] = [
  ["wiki/entities/", "Entities"],
  ["wiki/concepts/", "Concepts"],
]

function categorizePath(absPath: string): string {
  const norm = absPath.replace(/\\/g, "/")
  for (const [prefix, cat] of PATH_PREFIX_TO_CAT) {
    if (norm.includes(prefix)) return cat
  }
  return "Other"
}

function slugFromPath(absPath: string): string {
  const norm = absPath.replace(/\\/g, "/")
  const match = norm.match(/(?:^|\/)wiki\/(?:entities|concepts)\/([^/]+)\.md$/)
  return match ? match[1] : ""
}

export function formatRelatedPages(
  results: { path: string; title: string; snippet: string }[],
): string {
  if (results.length === 0) return ""

  const groups = new Map<string, { title: string; slug: string; snippet: string }[]>()
  for (const r of results) {
    const cat = categorizePath(r.path)
    if (!groups.has(cat)) groups.set(cat, [])
    groups.get(cat)!.push({
      title: r.title,
      slug: slugFromPath(r.path),
      snippet: r.snippet,
    })
  }

  const sortedCats = [...groups.entries()].sort(
    (a, b) => (CATEGORY_RANK[a[0]] ?? 99) - (CATEGORY_RANK[b[0]] ?? 99),
  )

  const lines: string[] = [
    "## Related Wiki Pages",
    "",
    "| slug | 标题 | 类型 |",
    "|---|---|---|",
  ]
  for (const [cat, entries] of sortedCats) {
    entries.sort((a, b) => a.title.localeCompare(b.title))
    const type = cat === "Entities" ? "entity" : "concept"
    for (const e of entries) {
      const slug = e.slug || e.title.toLowerCase().replace(/\s+/g, "-")
      const title = e.title || slug
      lines.push(`| ${slug} | ${title} | ${type} |`)
    }
  }
  return lines.join("\n") + "\n"
}

export function buildSourceSearchQuery(
  sourceIdentity: string,
  sourceContent: string,
): string {
  const name = sourceIdentity.replace(/\.(md|pdf|docx|pptx|xlsx|xls|txt)$/i, "").replace(/[/\\]/g, " ")
  const contentPrefix = sourceContent
    .replace(/^---+[\s\S]*?---+/, "")
    .replace(/#{1,6}\s*/g, "")
    .slice(0, 5000)
    .trim()
  return name + " " + contentPrefix
}

/**
 * Append manifest pages (from Step 1 analysis recommendations) into
 * the related-pages markdown table so the generation LLM sees both
 * existing wiki pages AND pages to be created in this batch.
 *
 * New rows are deduplicated against slugs already present in the table.
 */
export function mergeRelatedPages(
  relatedPages: string,
  manifestPages: { slug: string; title: string; type: string }[],
): string {
  if (manifestPages.length === 0) return relatedPages

  const existingSlugs = new Set<string>()
  for (const line of relatedPages.split("\n")) {
    const trimmed = line.trim()
    if (trimmed.startsWith("|") && trimmed.endsWith("|")) {
      const parts = trimmed.split("|").map(s => s.trim()).filter(Boolean)
      if (parts.length >= 3 && parts[0] && parts[0] !== "slug") {
        existingSlugs.add(parts[0])
      }
    }
  }

  const entities = manifestPages.filter(p => p.type === "entity" && !existingSlugs.has(p.slug))
  const concepts = manifestPages.filter(p => p.type === "concept" && !existingSlugs.has(p.slug))

  let output = relatedPages
  if (!output) {
    output = "## Related Wiki Pages\n\n| slug | 标题 | 类型 |\n|---|---|---|"
  }

  if (entities.length > 0) {
    for (const p of entities) {
      output += `\n| ${p.slug} | ${p.title || p.slug} | ${p.type} |`
    }
  }

  if (concepts.length > 0) {
    for (const p of concepts) {
      output += `\n| ${p.slug} | ${p.title || p.slug} | ${p.type} |`
    }
  }

  return output
}

export async function searchRelatedWikiPages(
  projectPath: string,
  sourceIdentity: string,
  sourceContent: string,
): Promise<string> {
  try {
    const query = buildSourceSearchQuery(sourceIdentity, sourceContent)
    if (!query.trim()) return ""
    const { results, mode, tokenHits, vectorHits } = await searchWiki(projectPath, query, 100)
    if (!results || results.length === 0) return ""
    const filtered = results.filter((r) => {
      const norm = r.path.replace(/\\/g, "/")
      return norm.includes("wiki/entities/") || norm.includes("wiki/concepts/")
    }).slice(0, RELATED_PAGE_MAX)
    try {
      const logEntry = {
        timestamp: new Date().toISOString(),
        source: sourceIdentity,
        queryLength: query.length,
        queryPreview: query.slice(0, 200),
        mode,
        tokenHits,
        vectorHits,
        topK: 100,
        totalResults: results.length,
        entityConceptResults: filtered.length,
      }
      const logPath = `${projectPath.replace(/\\/g, "/")}/wiki/ingest-search-diag.log`
      const existing = await readFile(logPath).catch(() => "")
      await writeFile(logPath, existing + JSON.stringify(logEntry) + "\n")
    } catch {
    }
    if (filtered.length === 0) return ""
    return formatRelatedPages(filtered)
  } catch {
    return ""
  }
}
