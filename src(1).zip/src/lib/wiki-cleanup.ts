export interface DeletedPageInfo {
  slug: string
  title: string
}

export function normalizeWikiRefKey(s: string): string {
  const normalized = s.trim().replace(/\\/g, "/")
  const leaf = normalized.split("/").pop() ?? normalized
  const withoutMd = leaf.toLowerCase().endsWith(".md") ? leaf.slice(0, -3) : leaf
  return withoutMd.toLowerCase().replace(/[\s\-_]+/g, "")
}

export function buildDeletedKeys(infos: DeletedPageInfo[]): Set<string> {
  const keys = new Set<string>()
  for (const info of infos) {
    if (info.slug) keys.add(normalizeWikiRefKey(info.slug))
    if (info.title) keys.add(normalizeWikiRefKey(info.title))
  }
  return keys
}

export function extractFrontmatterTitle(content: string): string {
  const m = content.match(/^title:\s*["']?(.+?)["']?\s*$/m)
  return m ? m[1].trim() : ""
}

const INDEX_ENTRY_RE = /^\s*[-*]\s*\[\[([^\]|]+?)(?:\|[^\]]+)?\]\]/
const INDEX_TABLE_ENTRY_RE = /^\|\s*(.+?)\s*\|\s*(.+?)\s*\|\s*wiki\/(?:entities|concepts|sources)\/(.+)\.md\s*\|$/
const INDEX_SLUG_TITLE_RE = /^([a-z][a-z0-9-]+)\s*\|\s*.+$/

export function cleanIndexListing(text: string, deletedKeys: Set<string>): string {
  if (deletedKeys.size === 0) return text
  return text
    .split("\n")
    .filter((line) => {
      const m = line.match(INDEX_ENTRY_RE)
      if (m) return !deletedKeys.has(normalizeWikiRefKey(m[1].trim()))
      const t = line.match(INDEX_TABLE_ENTRY_RE)
      if (t) return !deletedKeys.has(normalizeWikiRefKey(t[2].trim()))
      const st = line.match(INDEX_SLUG_TITLE_RE)
      if (st) return !deletedKeys.has(normalizeWikiRefKey(st[1].trim()))
      return true
    })
    .join("\n")
}
