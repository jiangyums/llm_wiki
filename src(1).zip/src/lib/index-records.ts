import { readFile, writeFile, listDirectory } from "@/commands/fs"
import { parseFrontmatter } from "@/lib/frontmatter"
import { getFileName } from "@/lib/path-utils"

export interface IndexEntry {
  title: string
  path: string
}

export interface IndexSection {
  category: string
  entries: IndexEntry[]
}

const INDEX_ENTRY_3COL_RE = /^\|\s*(.+?)\s*\|\s*(.+?)\s*\|\s*(wiki\/.+\.md)\s*\|$/
const INDEX_ENTRY_2COL_RE = /^\|\s*(.+?)\s*\|\s*(wiki\/.+\.md)\s*\|$/
const INDEX_ENTRY_SLUG_TITLE_RE = /^([a-z][a-z0-9-]+)\s*\|\s*(.+)$/
const INDEX_LEGACY_LIST_RE = /^\s*[-*]\s*\[\[([^\]|]+)/
const INDEX_SLUG_RE = /^[a-z][a-z0-9-]+$/

function parseIndexEntry(line: string, sectionDir?: string): IndexEntry | null {
  const t3 = line.match(INDEX_ENTRY_3COL_RE)
  if (t3) return { title: t3[1].trim(), path: t3[3].trim() }
  const t2 = line.match(INDEX_ENTRY_2COL_RE)
  if (t2) return { title: t2[1].trim(), path: t2[2].trim() }
  const legacy = line.match(INDEX_LEGACY_LIST_RE)
  if (legacy) return { title: legacy[1].trim(), path: `wiki/entities/${legacy[1].trim()}.md` }
  if (INDEX_SLUG_RE.test(line.trim())) {
    const slug = line.trim()
    return { title: slug, path: `${sectionDir ?? "wiki/entities"}/${slug}.md` }
  }
  const st = line.match(INDEX_ENTRY_SLUG_TITLE_RE)
  if (st) {
    const slug = st[1].trim()
    return { title: st[2].trim(), path: `${sectionDir ?? "wiki/entities"}/${slug}.md` }
  }
  return null
}

function normalizeCategory(headerLine: string): string {
  const name = headerLine.replace(/^#+\s*/, "")
  return name.replace(/\s+/g, "")
}

const PATH_ROUTE: Record<string, string> = {
  "wiki/entities/": "Entities",
  "wiki/concepts/": "Concepts",
  "wiki/sources/": "Sources",
  "wiki/queries/": "Queries",
  "wiki/comparisons/": "Comparisons",
  "wiki/synthesis/": "Synthesis",
  "wiki/themes/": "Themes",
  "wiki/plot-threads/": "PlotThreads",
}

function routeCategoryByPath(path: string): string {
  for (const [prefix, cat] of Object.entries(PATH_ROUTE)) {
    if (path.startsWith(prefix)) return cat
  }
  return "Entities"
}

export function parseIndexContent(content: string, onError: (msg: string) => void): IndexSection[] {
  const sections = new Map<string, IndexSection>()
  let currentCategory = ""
  let thirdLevelCategory = ""
  const seenPaths = new Set<string>()

  for (const line of content.split("\n")) {
    if (line.startsWith("# ") || line.trim() === "") {
      continue
    }
    if (line.startsWith("## ")) {
      currentCategory = normalizeCategory(line)
      thirdLevelCategory = ""
      if (!sections.has(currentCategory)) {
        sections.set(currentCategory, { category: currentCategory, entries: [] })
      }
      continue
    }
    if (line.startsWith("### ")) {
      const raw = line.replace(/^###\s*/, "")
      onError(`index.md: invalid third-level header '${line.trim()}'`)
      thirdLevelCategory = raw
      continue
    }
    const sectionDir = categoryToDir(currentCategory)
    const entry = parseIndexEntry(line, sectionDir)
    if (!entry) continue
    if (seenPaths.has(entry.path)) continue
    seenPaths.add(entry.path)
    const cat = thirdLevelCategory ? routeCategoryByPath(entry.path) : currentCategory
    if (!cat) continue
    if (!sections.has(cat)) {
      sections.set(cat, { category: cat, entries: [] })
    }
    sections.get(cat)!.entries.push(entry)
  }
  return [...sections.values()]
}

const CATEGORY_DIR: Record<string, string> = {
  Entities: "wiki/entities",
  Concepts: "wiki/concepts",
  Sources: "wiki/sources",
  Queries: "wiki/queries",
  Comparisons: "wiki/comparisons",
  Synthesis: "wiki/synthesis",
  Themes: "wiki/themes",
  PlotThreads: "wiki/plot-threads",
}

function categoryToDir(category: string): string {
  return CATEGORY_DIR[category] ?? "wiki/entities"
}


export function serializeIndexSections(sections: IndexSection[]): string {
  const parts: string[] = ["# Wiki Index"]
  for (const section of sections) {
    if (section.entries.length === 0) continue
    parts.push("")
    parts.push(`## ${section.category}`)
    for (const entry of section.entries) {
      const slug = entry.path.replace(/^wiki\/[^/]+\//, "").replace(/\.md$/, "")
      parts.push(`${slug} | ${entry.title}`)
    }
  }
  return parts.join("\n")
}

// ── WikiIndex: Unified page registry ──

export interface PageRecord {
  title: string
  type: string
  path: string
}

export class WikiIndex {
  pages = new Map<string, PageRecord>()  // key = slug (filename without .md)

  findBySlug(slug: string): PageRecord | null {
    return this.pages.get(slug) ?? null
  }

  findByTitle(title: string): PageRecord[] {
    const lower = title.toLowerCase().trim()
    const result: PageRecord[] = []
    for (const record of this.pages.values()) {
      if (record.title.toLowerCase().trim() === lower) {
        result.push(record)
      }
    }
    return result
  }

  register(slug: string, title: string, type: string, path: string): void {
    this.pages.set(slug, { title, type, path })
  }

  unregister(slug: string): void {
    this.pages.delete(slug)
  }

  async rebuildFromDisk(projectPath: string): Promise<void> {
    const newPages = new Map<string, PageRecord>()
    const walkers: Array<{ dir: string; type: string }> = [
      { dir: "wiki/entities", type: "entity" },
      { dir: "wiki/concepts", type: "concept" },
      { dir: "wiki/sources", type: "source" },
    ]
    for (const { dir, type } of walkers) {
      let nodes: import("@/types/wiki").FileNode[]
      try {
        nodes = await listDirectory(`${projectPath}/${dir}`)
      } catch {
        continue
      }
      const visit = async (items: import("@/types/wiki").FileNode[]) => {
        for (const item of items) {
          if (item.is_dir && item.children) {
            await visit(item.children)
            continue
          }
          if (!item.path.endsWith(".md")) continue
          const slug = getFileName(item.path).replace(/\.md$/, "")
          let fullPath = item.path
          if (!fullPath.startsWith("/") && !fullPath.includes(":")) {
            fullPath = `${projectPath}/${dir}/${item.name}`
          }
          try {
            const content = await readFile(fullPath)
            const title = extractTitleFromContent(content) || slug
            newPages.set(slug, { title, type, path: `${dir}/${slug}.md` })
          } catch {
            newPages.set(slug, { title: slug, type, path: `${dir}/${slug}.md` })
          }
        }
      }
      await visit(nodes)
    }
    this.pages = newPages
    const count = (type: string) => [...this.pages.values()].filter(r => r.type === type).length
    console.log(`[wikiIndex] rebuildFromDisk: ${this.pages.size} pages (entities=${count("entity")}, concepts=${count("concept")}, sources=${count("source")})`)
    for (const [slug, record] of this.pages) {
      if (record.title !== slug) {
        console.log(`[wikiIndex]   ${record.type} "${slug}" → title="${record.title}"`)
      }
    }
    await this.writeIndexMd(projectPath)
  }

  private async writeIndexMd(projectPath: string): Promise<void> {
    const sections = new Map<string, IndexSection>()
    for (const record of this.pages.values()) {
      const category = routeCategoryByPath(record.path)
      if (!sections.has(category)) {
        sections.set(category, { category, entries: [] })
      }
      sections.get(category)!.entries.push({ title: record.title, path: record.path })
    }
    // Sort entries by slug within each section
    for (const section of sections.values()) {
      section.entries.sort((a, b) => a.path.localeCompare(b.path))
    }
    const sorted = [...sections.values()].sort((a, b) => {
      const order = ["Entities", "Concepts", "Sources", "Queries", "Comparisons", "Synthesis", "Themes", "PlotThreads"]
      return order.indexOf(a.category) - order.indexOf(b.category)
    })
    const content = serializeIndexSections(sorted)
    await writeFile(`${projectPath}/wiki/index.md`, content)
  }
}

function extractTitleFromContent(content: string): string | null {
  const parsed = parseFrontmatter(content)
  if (typeof parsed.frontmatter?.title === "string" && parsed.frontmatter.title.trim()) {
    return parsed.frontmatter.title.trim()
  }
  const heading = content.match(/^#\s+(.+)$/m)?.[1]?.trim()
  return heading || null
}

export const wikiIndex = new WikiIndex()
