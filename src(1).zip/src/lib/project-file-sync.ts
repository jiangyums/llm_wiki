import { listen, type UnlistenFn } from "@tauri-apps/api/event"
import { readFile, writeFile, fileExists } from "@/commands/fs"
import {
  rescanProjectFiles,
  startProjectFileWatcher,
  stopProjectFileWatcher,
  type FileSyncPayload,
} from "@/commands/file-sync"
import { useFileSyncStore } from "@/stores/file-sync-store"
import { useWikiStore } from "@/stores/wiki-store"
import { getFileStem, normalizePath } from "@/lib/path-utils"
import type { WikiProject } from "@/types/wiki"
import type { SourceWatchConfig } from "@/stores/wiki-store"
import type { FileChangeTask } from "@/commands/file-sync"
import {
  cleanupDeletedWikiPages,
  deleteSourceFiles,
  enqueueSourceIngest,
  isIngestableSourcePath,
} from "@/lib/source-lifecycle"
import { isPathAllowedBySourceWatch, normalizeSourceWatchConfig } from "@/lib/source-watch-config"
import { refreshProjectFileTree } from "@/lib/project-file-tree-refresh"
import { wikiIndex } from "@/lib/index-records"

let unlistenQueue: UnlistenFn | null = null
let unlistenChanged: UnlistenFn | null = null
let startSeq = 0
let refreshTimer: ReturnType<typeof setTimeout> | null = null
let pendingRefreshPaths = new Set<string>()
let pendingChangeTasks = new Map<string, FileChangeTask>()
let activeSourceWatchConfig = normalizeSourceWatchConfig()
let handledChangeTaskKeys = new Set<string>()

export async function startProjectFileSync(
  project: WikiProject,
  sourceWatchConfig?: SourceWatchConfig,
): Promise<void> {
  await stopProjectFileSync()
  const seq = ++startSeq
  activeSourceWatchConfig = normalizeSourceWatchConfig(sourceWatchConfig)
  useFileSyncStore.getState().setRunning(true)
  useFileSyncStore.getState().setLastError(null)

  unlistenQueue = await listen<FileSyncPayload>("file-sync://queue-updated", (event) => {
    if (event.payload.projectId !== useWikiStore.getState().project?.id) return
    useFileSyncStore.getState().setTasks(event.payload.tasks)
  })

  unlistenChanged = await listen<FileSyncPayload>("file-sync://changed", (event) => {
    const current = useWikiStore.getState().project
    if (!current || event.payload.projectId !== current.id) return
    console.log(`[file-sync:diag] received ${event.payload.tasks.length} changed tasks from Rust watcher`)
    for (const t of event.payload.tasks) {
      console.log(`[file-sync:diag]   event task: kind=${t.kind} path=${t.path} status=${t.status} mtimeMs=${t.mtimeMs}`)
    }
    scheduleRefreshAfterFileChanges(event.payload.tasks)
  })

  try {
    const result = await startProjectFileWatcher(project.id, normalizePath(project.path), activeSourceWatchConfig)
    if (seq !== startSeq || project.id !== useWikiStore.getState().project?.id) return
    console.log(`[file-sync:diag] startup: ${result.changedTasks.length} changed tasks from watcher, ${pendingChangeTasks.size} pending from events`)
    for (const t of result.changedTasks) {
      console.log(`[file-sync:diag]   watcher task: kind=${t.kind} path=${t.path} status=${t.status}`)
    }
    const startupChangedTasks = mergeChangeTasks([
      ...result.changedTasks,
      ...pendingChangeTasks.values(),
    ].filter((task) => task.projectId === project.id))
      .filter((task) => !handledChangeTaskKeys.has(changeTaskKey(task)))
    console.log(`[file-sync:diag]   after merge/filter: ${startupChangedTasks.length} tasks to process`)
    for (const t of startupChangedTasks) {
      console.log(`[file-sync:diag]     merged task: kind=${t.kind} path=${t.path}`)
    }
    pendingRefreshPaths.clear()
    pendingChangeTasks.clear()
    if (refreshTimer) {
      clearTimeout(refreshTimer)
      refreshTimer = null
    }
    useFileSyncStore.getState().setTasks(result.queue.tasks)
    if (startupChangedTasks.length > 0) {
      const paths = [...new Set(startupChangedTasks.map((task) => task.path))]
      await processFileChangeBatch(project, paths, startupChangedTasks)
    } else {
      console.log(`[file-sync:diag]   no startup changed tasks — refreshAfterFileChanges`)
    }
    // Re-enqueue any raw source files that are in the file-snapshot but
    // missing from the ingest-cache. This covers files that were detected
    // by the watcher in a previous session but never made it through the
    // ingest queue (e.g. due to a transient error during enqueueBatch).
    await enqueueOrphanedRawSources(project)
    // Rebuild wiki index from disk after project opens
    wikiIndex.rebuildFromDisk(project.path).catch(() => {})
  } catch (err) {
    unlistenQueue?.()
    unlistenChanged?.()
    unlistenQueue = null
    unlistenChanged = null
    useFileSyncStore.getState().setLastError(String(err))
    throw err
  } finally {
    if (seq === startSeq) {
      useFileSyncStore.getState().setRunning(false)
    }
  }
}

export async function stopProjectFileSync(): Promise<void> {
  startSeq++
  unlistenQueue?.()
  unlistenChanged?.()
  unlistenQueue = null
  unlistenChanged = null
  if (refreshTimer) {
    clearTimeout(refreshTimer)
    refreshTimer = null
  }
  pendingRefreshPaths.clear()
  pendingChangeTasks.clear()
  handledChangeTaskKeys.clear()
  useFileSyncStore.getState().clear()
  try {
    await stopProjectFileWatcher()
  } catch {
    // App startup/project switching should not fail just because a stale
    // watcher has already been dropped by the backend.
  }
}

export async function rescanProjectFileSync(
  project: WikiProject,
  sourceWatchConfig?: SourceWatchConfig,
): Promise<void> {
  const config = normalizeSourceWatchConfig(sourceWatchConfig ?? useWikiStore.getState().sourceWatchConfig)
  activeSourceWatchConfig = config

  const result = await rescanProjectFiles(project.id, normalizePath(project.path), config)
  if (useWikiStore.getState().project?.id !== project.id) return
  useFileSyncStore.getState().setTasks(result.queue.tasks)

  if (useWikiStore.getState().project?.id !== project.id) return
  if (result.changedTasks.length > 0) {
    const paths = [...new Set(result.changedTasks.map((task) => task.path))]
    await processFileChangeBatch(project, paths, result.changedTasks)
  } else {
    await refreshAfterFileChanges(project, [])
  }
}

function scheduleRefreshAfterFileChanges(tasks: FileChangeTask[]): void {
  for (const task of tasks) {
    pendingRefreshPaths.add(task.path)
    pendingChangeTasks.set(task.path, task)
  }
  if (refreshTimer) return
  refreshTimer = setTimeout(() => {
    refreshTimer = null
    const project = useWikiStore.getState().project
    if (!project) {
      pendingRefreshPaths.clear()
      pendingChangeTasks.clear()
      return
    }
    const tasks = mergeChangeTasks([...pendingChangeTasks.values()])
      .filter((task) => !handledChangeTaskKeys.has(changeTaskKey(task)))
    const paths = tasks.length > 0
      ? [...new Set(tasks.map((task) => task.path))]
      : [...pendingRefreshPaths]
    pendingRefreshPaths.clear()
    pendingChangeTasks.clear()
    void processFileChangeBatch(project, paths, tasks)
  }, 250)
}

function mergeChangeTasks(tasks: FileChangeTask[]): FileChangeTask[] {
  const byKey = new Map<string, FileChangeTask>()
  for (const task of tasks) {
    byKey.set(changeTaskKey(task), task)
  }
  return [...byKey.values()]
}

function changeTaskKey(task: FileChangeTask): string {
  const version = task.updatedAt ?? task.createdAt ?? 0
  return task.id
    ? `${task.id}:${version}`
    : `${task.projectId}:${task.path}:${task.kind}:${version}`
}

async function processFileChangeBatch(
  project: WikiProject,
  paths: string[],
  tasks: FileChangeTask[],
): Promise<void> {
  console.log(`[file-sync:diag] processFileChangeBatch: ${tasks.length} tasks, ${paths.length} unique paths`)
  for (const path of paths) {
    console.log(`[file-sync:diag]   batch path: ${path}`)
  }
  for (const task of tasks) {
    handledChangeTaskKeys.add(changeTaskKey(task))
  }
  if (handledChangeTaskKeys.size > 4096) {
    handledChangeTaskKeys = new Set([...handledChangeTaskKeys].slice(-2048))
  }
  await cleanupDeletedFiles(project, tasks)
  await enqueueRawSourceChanges(project, tasks)
  await refreshAfterFileChanges(project, paths)
}

async function refreshAfterFileChanges(project: WikiProject, relativePaths: string[]): Promise<void> {
  const pp = normalizePath(project.path)
  const store = useWikiStore.getState()
  await refreshProjectFileTree(pp, {
    projectId: project.id,
    bumpDataVersion: true,
  })

  const selected = store.selectedFile ? normalizePath(store.selectedFile) : null
  if (!selected) return

  const selectedRel = selected.startsWith(`${pp}/`) ? selected.slice(pp.length + 1) : selected
  if (!relativePaths.includes(selectedRel)) return

  try {
    const content = await readFile(selected)
    useWikiStore.getState().setFileContent(content)
  } catch {
    useWikiStore.getState().setSelectedFile(null)
    useWikiStore.getState().setFileContent("")
  }
}

let diagLogBuffer: string[] = []

function flushDiagLog(): void {
  const buf = diagLogBuffer
  diagLogBuffer = []
  if (buf.length === 0) return
  const project = useWikiStore.getState().project
  if (!project) return
  const pp = normalizePath(project.path)
  const text = buf.join("") + "\n"
  writeFile(`${pp}/.llm-wiki/diag-enqueue.log`, text).catch(() => {})
}

function diagLog(msg: string): void {
  const ts = new Date().toISOString().slice(11, 23)
  const line = `[${ts}] ${msg}`
  console.log(`[enqueue-diag] ${line}`)
  diagLogBuffer.push(line + "\n")
  if (diagLogBuffer.length >= 10) flushDiagLog()
}

async function enqueueOrphanedRawSources(project: WikiProject): Promise<void> {
  const pp = normalizePath(project.path)
  let snapshotRaw: string
  try {
    snapshotRaw = await readFile(`${pp}/.llm-wiki/file-snapshot.json`)
  } catch {
    return
  }
  let snapshot: { files: Record<string, { hash?: string; size: number; mtimeMs: number }> }
  try {
    snapshot = JSON.parse(snapshotRaw)
  } catch {
    return
  }

  let cacheRaw: string
  try {
    cacheRaw = await readFile(`${pp}/.llm-wiki/ingest-cache.json`)
  } catch {
    cacheRaw = '{"entries":{}}'
  }
  let cache: { entries: Record<string, unknown> }
  try {
    cache = JSON.parse(cacheRaw)
  } catch {
    cache = { entries: {} }
  }

  const RAW_SOURCES_PREFIX = "raw/sources/"
  const orphaned: string[] = []
  for (const relPath of Object.keys(snapshot.files)) {
    const norm = normalizePath(relPath)
    if (!norm.startsWith(RAW_SOURCES_PREFIX)) continue
    if (!isIngestableSourcePath(norm)) continue
    const cacheKey = norm.slice(RAW_SOURCES_PREFIX.length)
    if (cacheKey in cache.entries) continue
    if (!(await fileExists(`${pp}/${norm}`))) continue
    orphaned.push(norm)
  }

  if (orphaned.length === 0) return
  console.log(`[file-sync:diag] enqueueOrphanedRawSources: ${orphaned.length} files in snapshot but not in ingest-cache`)
  for (const p of orphaned) console.log(`[file-sync:diag]   orphaned: ${p}`)
  diagLog(`enqueueOrphanedRawSources: ${orphaned.length} orphaned files found`)
  const llmConfig = useWikiStore.getState().llmConfig
  if (!llmConfig?.provider) {
    diagLog(`  SKIP: no LLM configured (provider=${llmConfig?.provider})`)
    return
  }
  diagLog(`  calling enqueueSourceIngest with ${orphaned.length} paths`)
  try {
    const ids = await enqueueSourceIngest(project, orphaned, llmConfig)
    diagLog(`  enqueueSourceIngest returned ids: ${ids.length > 0 ? ids.join(", ") : "EMPTY (all filtered out by enqueueSourceIngest)"}`)
    if (ids.length === 0) {
      diagLog(`  possible cause: hasUsableLlm returned false, or all paths filtered by isIngestableSourcePath/isSensitiveConfigSourceFile`)
    }
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err)
    diagLog(`  EXCEPTION from enqueueSourceIngest: ${msg}`)
    console.error("[file-sync] failed to enqueue orphaned raw sources:", err)
  }
}

async function enqueueRawSourceChanges(project: WikiProject, tasks: FileChangeTask[]): Promise<void> {
  const config = normalizeSourceWatchConfig(activeSourceWatchConfig)
  diagLog(`enqueueRawSourceChanges: ${tasks.length} tasks, enabled=${config.enabled} autoIngest=${config.autoIngest}`)
  if (!config.enabled || !config.autoIngest) {
    diagLog(`  SKIP: enabled=${config.enabled} autoIngest=${config.autoIngest}`)
    return
  }

  for (const t of tasks) {
    diagLog(`  task: kind=${t.kind} path=${t.path} projectId=${t.projectId} id=${t.id}`)
  }

  const filteredByProject = tasks.filter((task) => task.projectId === project.id)
  const filteredByKind = filteredByProject.filter((task) => task.kind === "created" || task.kind === "modified")
  const pathsFromTasks = filteredByKind.map((task) => task.path)
  const ingestablePaths = pathsFromTasks.filter(isIngestableRawSource)

  // Log which tasks were filtered out and why
  for (const t of tasks) {
    if (t.projectId !== project.id) {
      diagLog(`  FILTER: projectId mismatch: task=${t.projectId} expected=${project.id}`)
    } else if (t.kind !== "created" && t.kind !== "modified") {
      diagLog(`  FILTER: kind not created/modified: ${t.kind}`)
    } else if (!isIngestableRawSource(t.path)) {
      diagLog(`  FILTER: not ingestable raw source: ${t.path}`)
    }
  }

  const paths = ingestablePaths.filter((rel) => isPathAllowedBySourceWatch(rel, config))
  diagLog(`  after filter: ${ingestablePaths.length} ingestable, ${paths.length} allowed by watch config`)

  if (paths.length === 0) {
    diagLog(`  no paths remaining after filter — returning early`)
    return
  }

  const llmConfig = useWikiStore.getState().llmConfig
  if (!llmConfig?.provider) {
    diagLog(`  SKIP before enqueueSourceIngest: LLM provider missing`)
    return
  }
  diagLog(`  calling enqueueSourceIngest with ${paths.length} paths: ${paths.join(", ")}`)
  try {
    const ids = await enqueueSourceIngest(project, paths, llmConfig)
    diagLog(`  enqueueSourceIngest returned ${ids.length} ids: ${ids.length > 0 ? ids.join(", ") : "EMPTY"}`)
    if (ids.length === 0) {
      diagLog(`  possible cause: hasUsableLlm false, or isIngestableSourcePath/isSensitiveConfigSourceFile filtered all`)
    }
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err)
    diagLog(`  EXCEPTION: ${msg}`)
    console.error("[file-sync] failed to enqueue raw source ingest:", err)
  }
}

function isIngestableRawSource(relativePath: string): boolean {
  const path = normalizePath(relativePath)
  if (!path.startsWith("raw/sources/")) return false
  return isIngestableSourcePath(path)
}

async function cleanupDeletedFiles(project: WikiProject, tasks: FileChangeTask[]): Promise<void> {
  const deleted = tasks
    .filter((task) => task.projectId === project.id && task.kind === "deleted")
    .map((task) => normalizePath(task.path))

  if (deleted.length === 0) return

  const rawSources = deleted.filter(isRawSourcePathForCascade)
  const wikiPages = deleted.filter(isWikiPageForCascade)

  let deletedWikiSlugs = new Set<string>()
  if (rawSources.length > 0) {
    try {
      const result = await deleteSourceFiles(project.path, rawSources, {
        fileAlreadyDeleted: true,
        logReason: rawSources.length === 1 ? "external delete" : "external batch delete",
      })
      deletedWikiSlugs = new Set(result.deletedWikiPaths.map((path) => getFileStem(path)))
    } catch (err) {
      console.error("[file-sync] failed to clean deleted raw sources:", err)
    }
  }

  const wikiPagesToClean = wikiPages.filter((path) => !deletedWikiSlugs.has(getFileStem(path)))
  if (wikiPagesToClean.length > 0) {
    try {
      await cleanupDeletedWikiPages(project.path, wikiPagesToClean)
    } catch (err) {
      console.error("[file-sync] failed to clean deleted wiki pages:", err)
    }
  }
}

function isRawSourcePathForCascade(relativePath: string): boolean {
  const path = normalizePath(relativePath)
  if (!path.startsWith("raw/sources/")) return false
  if (path.includes("/.cache/")) return false
  const fileName = path.split("/").pop() ?? ""
  return Boolean(fileName && !fileName.startsWith("."))
}

function isWikiPageForCascade(relativePath: string): boolean {
  const path = normalizePath(relativePath)
  const lower = path.toLowerCase()
  if (!lower.startsWith("wiki/") || !lower.endsWith(".md")) return false
  const name = lower.split("/").pop()
  if (name === "index.md" || name === "overview.md") {
    return false
  }
  return !lower.startsWith("wiki/media/")
}
