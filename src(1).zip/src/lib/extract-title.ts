import type { ProjectPathIndex } from "./wiki-page-resolver"
import { readFile } from "@/commands/fs"
import { normalizePath } from "@/lib/path-utils"

export function extractTitle(content: string, fileName: string): string {
  const frontmatterTitleMatch = content.match(/^\s*---\n[\s\S]*?^title:\s*["']?(.+?)["']?\s*$/m)
  if (frontmatterTitleMatch) return frontmatterTitleMatch[1].trim()

  const headingMatch = content.match(/^#\s+(.+)$/m)
  if (headingMatch) return headingMatch[1].trim()

  return fileName.replace(/\.md$/, "").replace(/-/g, " ")
}

function collectSlugs(index: ProjectPathIndex, wikiPrefix: string): { slug: string; basename: string; path: string; unique: boolean }[] {
  const mdFiles: { path: string; slug: string }[] = []

  for (const entry of index.byPath.values()) {
    if (entry.name.endsWith(".md")) {
      const path = normalizePath(entry.path)
      if (path.startsWith(wikiPrefix)) {
        const slug = path.slice(wikiPrefix.length).replace(/\.md$/, "")
        mdFiles.push({ path, slug })
      }
    }
  }

  // Count basename occurrences to detect collisions
  const basenameCount = new Map<string, number>()
  for (const { slug } of mdFiles) {
    const name = slug.split("/").pop()!
    basenameCount.set(name, (basenameCount.get(name) ?? 0) + 1)
  }

  return mdFiles.map(({ path, slug }) => ({
    slug,
    basename: slug.split("/").pop()!,
    path,
    unique: basenameCount.get(slug.split("/").pop()!) === 1,
  }))
}

export async function buildSlugTitleMap(
  index: ProjectPathIndex,
  wikiSubdir: string,
  projectPath: string,
): Promise<Record<string, string>> {
  const wikiPrefix = normalizePath(`${projectPath}/${wikiSubdir}`) + "/"
  const entries = collectSlugs(index, wikiPrefix)
  const map: Record<string, string> = {}

  const promises = entries.map(async ({ slug, basename, path, unique }) => {
    try {
      const content = await readFile(path)
      const title = extractTitle(content, slug)
      map[slug] = title
      if (unique) map[basename] = title
    } catch {
      // skip unreadable files
    }
  })

  await Promise.all(promises)
  return map
}
